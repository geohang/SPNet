%% Sub-Function for the Finite Element Method
function Kfinite=Subfunction_Finite_Hexahedron(SGM,I8,XYZ,NX,NY,NZ,ND)
Kfinite=sparse(ND,ND);
k1=[4 2 -2 -4 2 1 -1 -2;2 4 -4 -2 1 2 -2 -1;-2 -4 4 2 -1 -2 2 1;-4 -2 2 4 -2 -1 1 2;
    2 1 -1 -2 4 2 -2 -4;1 2 -2 -1 2 4 -4 -2;-1 -2 2 1 -2 -4 4 2;-2 -1 1 2 -4 -2 2 4];
k2=[4,-4,-2,2,2,-2,-1,1;-4,4,2,-2,-2,2,1,-1;-2,2,4,-4,-1,1,2,-2;2,-2,-4,4,1,-1,-2,2;
    2,-2,-1,1,4,-4,-2,2;-2,2,1,-1,-4,4,2,-2;-1,1,2,-2,-2,2,4,-4;1,-1,-2,2,2,-2,-4,4];
k3=[4,2,1,2,-4,-2,-1,-2;2,4,2,1,-2,-4,-2,-1;1,2,4,2,-1,-2,-4,-2;2,1,2,4,-2,-1,-2,-4;
    -4,-2,-1,-2,4,2,1,2;-2,-4,-2,-1,2,4,2,1;-1,-2,-4,-2,1,2,4,2;-2,-1,-2,-4,2,1,2,4];
A=abs(XYZ(I8(1:NX*NY*NZ,1),1)-XYZ(I8(1:NX*NY*NZ,4),1));
B=abs(XYZ(I8(1:NX*NY*NZ,1),2)-XYZ(I8(1:NX*NY*NZ,2),2));
C=abs(XYZ(I8(1:NX*NY*NZ,1),3)-XYZ(I8(1:NX*NY*NZ,5),3));
sigma=SGM(1:NX*NY*NZ);
for i=1:8
    for j=1:8
        Kij=(k1(i,j)*B.*C./A+k2(i,j)*C.*A./B+k3(i,j)*A.*B./C).*sigma'/36;
        Kfinite=Kfinite+sparse(I8(1:NX*NY*NZ,i),I8(1:NX*NY*NZ,j),Kij,ND,ND);
    end
end
end